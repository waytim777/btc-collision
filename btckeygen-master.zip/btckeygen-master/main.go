package main

import (
	"bufio"
	"container/list"
	"flag"
	"fmt"
	"github.com/btcsuite/btcd/btcec"
	"github.com/btcsuite/btcd/chaincfg"
	"github.com/btcsuite/btcd/txscript"
	"github.com/btcsuite/btcutil"
	"github.com/tyler-smith/go-bip32"
	"github.com/tyler-smith/go-bip39"
	"log"
	"os"
	"strings"
	"sync"
)

// Purpose BIP43 - Purpose Field for Deterministic Wallets
// https://github.com/bitcoin/bips/blob/master/bip-0043.mediawiki
//
// Purpose is a constant set to 44' (or 0x8000002C) following the BIP43 recommendation.
// It indicates that the subtree of this node is used according to this specification.
//
// What does 44' mean in BIP44?
// https://bitcoin.stackexchange.com/questions/74368/what-does-44-mean-in-bip44
//
// 44' means that hardened keys should be used. The distinguisher for whether
// a key a given index is hardened is that the index is greater than 2^31,
// which is 2147483648. In hex, that is 0x80000000. That is what the apostrophe (') means.
// The 44 comes from adding it to 2^31 to get the final hardened key index.
// In hex, 44 is 2C, so 0x80000000 + 0x2C = 0x8000002C.
type Purpose = uint32

const (
	PurposeBIP44 Purpose = 0x8000002C // 44' BIP44
	PurposeBIP49 Purpose = 0x80000031 // 49' BIP49
	PurposeBIP84 Purpose = 0x80000054 // 84' BIP84
)

// CoinType SLIP-0044 : Registered coin types for BIP-0044
// https://github.com/satoshilabs/slips/blob/master/slip-0044.md
type CoinType = uint32

const (
	CoinTypeBTC CoinType = 0x80000000
	CoinTypeLTC CoinType = 0x80000002
	CoinTypeETH CoinType = 0x8000003c
	CoinTypeEOS CoinType = 0x800000c2
)

const (
	Apostrophe uint32 = 0x80000000 // 0'
)

type Key struct {
	path     string
	bip32Key *bip32.Key
}

func (k *Key) Encode(compress bool) (wif, address, segwitBech32, segwitNested string, err error) {
	prvKey, _ := btcec.PrivKeyFromBytes(btcec.S256(), k.bip32Key.Key)
	return GenerateFromBytes(prvKey, compress)
}

// https://github.com/bitcoin/bips/blob/master/bip-0044.mediawiki
// bip44 define the following 5 levels in BIP32 path:
// m / purpose' / coin_type' / account' / change / address_index

func (k *Key) GetPath() string {
	return k.path
}

type KeyManager struct {
	mnemonic   string
	passphrase string
	keys       map[string]*bip32.Key
	mux        sync.Mutex
}

// NewKeyManager return new key manager
// bitSize has to be a multiple 32 and be within the inclusive range of {128, 256}
// 128: 12 phrases
// 256: 24 phrases
func NewKeyManager(bitSize int, passphrase, mnemonic string) (*KeyManager, error) {

	if mnemonic == "" {
		entropy, err := bip39.NewEntropy(bitSize)
		if err != nil {
			return nil, err
		}
		mnemonic, err = bip39.NewMnemonic(entropy)
		if err != nil {
			return nil, err
		}
	}

	km := &KeyManager{
		mnemonic:   mnemonic,
		passphrase: passphrase,
		keys:       make(map[string]*bip32.Key, 0),
	}
	return km, nil
}

func (km *KeyManager) GetMnemonic() string {
	return km.mnemonic
}

func (km *KeyManager) GetPassphrase() string {
	return km.passphrase
}

func (km *KeyManager) GetSeed() []byte {
	return bip39.NewSeed(km.GetMnemonic(), km.GetPassphrase())
}

func (km *KeyManager) getKey(path string) (*bip32.Key, bool) {
	km.mux.Lock()
	defer km.mux.Unlock()

	key, ok := km.keys[path]
	return key, ok
}

func (km *KeyManager) setKey(path string, key *bip32.Key) {
	km.mux.Lock()
	defer km.mux.Unlock()

	km.keys[path] = key
}

func (km *KeyManager) GetMasterKey() (*bip32.Key, error) {
	path := "m"

	key, ok := km.getKey(path)
	if ok {
		return key, nil
	}

	key, err := bip32.NewMasterKey(km.GetSeed())
	if err != nil {
		return nil, err
	}

	km.setKey(path, key)

	return key, nil
}

func (km *KeyManager) GetPurposeKey(purpose uint32) (*bip32.Key, error) {
	path := fmt.Sprintf(`m/%d'`, purpose-Apostrophe)

	key, ok := km.getKey(path)
	if ok {
		return key, nil
	}

	parent, err := km.GetMasterKey()
	if err != nil {
		return nil, err
	}

	key, err = parent.NewChildKey(purpose)
	if err != nil {
		return nil, err
	}

	km.setKey(path, key)

	return key, nil
}

func (km *KeyManager) GetCoinTypeKey(purpose, coinType uint32) (*bip32.Key, error) {
	path := fmt.Sprintf(`m/%d'/%d'`, purpose-Apostrophe, coinType-Apostrophe)

	key, ok := km.getKey(path)
	if ok {
		return key, nil
	}

	parent, err := km.GetPurposeKey(purpose)
	if err != nil {
		return nil, err
	}

	key, err = parent.NewChildKey(coinType)
	if err != nil {
		return nil, err
	}

	km.setKey(path, key)

	return key, nil
}

func (km *KeyManager) GetAccountKey(purpose, coinType, account uint32) (*bip32.Key, error) {
	path := fmt.Sprintf(`m/%d'/%d'/%d'`, purpose-Apostrophe, coinType-Apostrophe, account)

	key, ok := km.getKey(path)
	if ok {
		return key, nil
	}

	parent, err := km.GetCoinTypeKey(purpose, coinType)
	if err != nil {
		return nil, err
	}

	key, err = parent.NewChildKey(account + Apostrophe)
	if err != nil {
		return nil, err
	}

	km.setKey(path, key)

	return key, nil
}

// GetChangeKey ...
// https://github.com/bitcoin/bips/blob/master/bip-0044.mediawiki#change
// change constant 0 is used for external chain
// change constant 1 is used for internal chain (also known as change addresses)
func (km *KeyManager) GetChangeKey(purpose, coinType, account, change uint32) (*bip32.Key, error) {
	path := fmt.Sprintf(`m/%d'/%d'/%d'/%d`, purpose-Apostrophe, coinType-Apostrophe, account, change)

	key, ok := km.getKey(path)
	if ok {
		return key, nil
	}

	parent, err := km.GetAccountKey(purpose, coinType, account)
	if err != nil {
		return nil, err
	}

	key, err = parent.NewChildKey(change)
	if err != nil {
		return nil, err
	}

	km.setKey(path, key)

	return key, nil
}

func (km *KeyManager) GetKey(purpose, coinType, account, change, index uint32) (*Key, error) {
	path := fmt.Sprintf(`m/%d'/%d'/%d'/%d/%d`, purpose-Apostrophe, coinType-Apostrophe, account, change, index)

	key, ok := km.getKey(path)
	if ok {
		return &Key{path: path, bip32Key: key}, nil
	}

	parent, err := km.GetChangeKey(purpose, coinType, account, change)
	if err != nil {
		return nil, err
	}

	key, err = parent.NewChildKey(index)
	if err != nil {
		return nil, err
	}

	km.setKey(path, key)

	return &Key{path: path, bip32Key: key}, nil
}

func Generate(compress bool) (wif, address, segwitBech32, segwitNested string, err error) {
	prvKey, err := btcec.NewPrivateKey(btcec.S256())
	if err != nil {
		return "", "", "", "", err
	}
	return GenerateFromBytes(prvKey, compress)
}

func GenerateFromBytes(prvKey *btcec.PrivateKey, compress bool) (wif, address, segwitBech32, segwitNested string, err error) {
	// generate the wif(wallet import format) string
	btcwif, err := btcutil.NewWIF(prvKey, &chaincfg.MainNetParams, compress)
	if err != nil {
		return "", "", "", "", err
	}
	wif = btcwif.String()

	// generate a normal p2pkh address
	serializedPubKey := btcwif.SerializePubKey()
	addressPubKey, err := btcutil.NewAddressPubKey(serializedPubKey, &chaincfg.MainNetParams)
	if err != nil {
		return "", "", "", "", err
	}
	address = addressPubKey.EncodeAddress()

	// generate a normal p2wkh address from the pubkey hash
	witnessProg := btcutil.Hash160(serializedPubKey)
	addressWitnessPubKeyHash, err := btcutil.NewAddressWitnessPubKeyHash(witnessProg, &chaincfg.MainNetParams)
	if err != nil {
		return "", "", "", "", err
	}
	segwitBech32 = addressWitnessPubKeyHash.EncodeAddress()

	// generate an address which is
	// backwards compatible to Bitcoin nodes running 0.6.0 onwards, but
	// allows us to take advantage of segwit's scripting improvments,
	// and malleability fixes.
	serializedScript, err := txscript.PayToAddrScript(addressWitnessPubKeyHash)
	if err != nil {
		return "", "", "", "", err
	}
	addressScriptHash, err := btcutil.NewAddressScriptHash(serializedScript, &chaincfg.MainNetParams)
	if err != nil {
		return "", "", "", "", err
	}
	segwitNested = addressScriptHash.EncodeAddress()

	return wif, address, segwitBech32, segwitNested, nil
}

var list1 []string

func jzlist1() {
	for i := 48; i < 58; i++ {
		var r rune = rune(i)
		var s string = string(r)
		list1 = append(list1, s)
		print(s)
	}
}

var listA []string

func jzlistA() {
	for i := 65; i < 91; i++ {
		var r rune = rune(i)
		var s string = string(r)
		listA = append(listA, s)
		print(s)
	}
}

var lista []string

func jzlista() {
	for i := 97; i < 123; i++ {
		var r rune = rune(i)
		var s string = string(r)
		lista = append(lista, s)
		print(s)
	}
}

var p2pkh_11 []string

func createp2pkh_11() {
	filename := "D://p/p2pkh_11.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2pkh_11 = strings.Split(string(data), "\r\n")
	print(len(p2pkh_11))
}

var p2pkh_1A []string

func createp2pkh_1A() {
	filename := "D://p/p2pkh_1Aszdx.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2pkh_1A = strings.Split(string(data), "\r\n")
	print(len(p2pkh_1A))
}

var p2pkh_1a []string

func createp2pkh_1a() {
	filename := "D://p/p2pkh_1aszxx.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2pkh_1a = strings.Split(string(data), "\r\n")
	print(len(p2pkh_1a))
}

var p2pkh_AA []string

func createp2pkh_AA() {
	filename := "D://p/p2pkh_AAdxdx.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2pkh_AA = strings.Split(string(data), "\r\n")
	print(len(p2pkh_AA))
}

var p2pkh_A1 []string

func createp2pkh_A1() {
	filename := "D://p/p2pkh_A1dxsz.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2pkh_A1 = strings.Split(string(data), "\r\n")
	print(len(p2pkh_A1))
}

var p2pkh_Aa []string

func createp2pkh_Aa() {
	filename := "D://p/p2pkh_Aadxxx.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2pkh_Aa = strings.Split(string(data), "\r\n")
	print(len(p2pkh_Aa))
}

var p2pkh_a1 []string

func createp2pkh_a1() {
	filename := "D://p/p2pkh_a1xxsz.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2pkh_a1 = strings.Split(string(data), "\r\n")
	print(len(p2pkh_a1))
}

var p2pkh_aa []string

func createp2pkh_aa() {
	filename := "D://p/p2pkh_aaxxxx.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2pkh_aa = strings.Split(string(data), "\r\n")
	print(len(p2pkh_aa))
}

var p2pkh_aA []string

func createp2pkh_aA() {
	filename := "D://p/p2pkh_aAxxdx.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2pkh_aA = strings.Split(string(data), "\r\n")
	print(len(p2pkh_aA))
}

var p2sh_1a []string

func createp2sh_1a() {
	filename := "D://p/p2sh_1aszxx.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2sh_1a = strings.Split(string(data), "\r\n")
	print(len(p2sh_1a))
}

var p2sh_11 []string

func createp2sh_11() {
	filename := "D://p/p2sh_11.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2sh_11 = strings.Split(string(data), "\r\n")
	print(len(p2sh_11))
}

var p2sh_1A []string

func createp2sh_1A() {
	filename := "D://p/p2sh_1Aszdx.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2sh_1A = strings.Split(string(data), "\r\n")
	print(len(p2sh_1A))
}

var p2sh_A1 []string

func createp2sh_A1() {
	filename := "D://p/p2sh_A1dxsz.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2sh_A1 = strings.Split(string(data), "\r\n")
	print(len(p2sh_A1))
}

var p2sh_AA []string

func createp2sh_AA() {
	filename := "D://p/p2sh_AAdxdx.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2sh_AA = strings.Split(string(data), "\r\n")
	print(len(p2sh_AA))
}

var p2sh_Aa []string

func createp2sh_Aa() {
	filename := "D://p/p2sh_Aadxxx.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2sh_Aa = strings.Split(string(data), "\r\n")
	print(len(p2sh_Aa))
}

var p2wpkh_1a []string

func createp2wpkh_1a() {
	filename := "D://p/p2wpkh_1a.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2wpkh_1a = strings.Split(string(data), "\r\n")
	print(len(p2wpkh_1a))
}

var p2wpkh_11 []string

func createp2wpkh_11() {
	filename := "D://p/p2wpkh_11.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2wpkh_11 = strings.Split(string(data), "\r\n")
	print(len(p2wpkh_11))
}

var p2wpkh_a1 []string

func createp2wpkh_a1() {
	filename := "D://p/p2wpkh_a1.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2wpkh_a1 = strings.Split(string(data), "\r\n")
	print(len(p2wpkh_a1))
}

var p2wpkh_aa []string

func createp2wpkh_aa() {
	filename := "D://p/p2wpkh_aa.txt"
	data, err_read := os.ReadFile(filename)
	if err_read != nil {
		fmt.Println("文件读取失败！")
	}
	p2wpkh_aa = strings.Split(string(data), "\r\n")
	print(len(p2wpkh_aa))
}

func Find(slice []string, val string) (int, bool) {
	for i, item := range slice {
		if item == val {
			return i, true
		}
	}
	return -1, false
}

func exits(slice []string, val string) bool {
	for i := 0; i < len(slice); i++ {
		if slice[i] == val {
			return true
		}
	}
	return false
}

func list_find(ll *list.List, address string) bool {
	for i := ll.Front(); i != nil; i = i.Next() {
		if i.Value == address {
			return true
		}
	}
	return false
}

func p2pkh_check(address string, wif string) {
	var addt = address[1:2]
	var addw = address[len(address)-1:]
	if exits(list1, addt) == true && exits(list1, addw) == true {
		for i := 0; i < len(p2pkh_11); i++ {
			if p2pkh_11[i] == address {
				xrfile(wif)
			}
		}
	}
	if exits(list1, addt) == true && exits(listA, addw) == true {
		for i := 0; i < len(p2pkh_1A); i++ {
			if p2pkh_1A[i] == address {
				xrfile(wif)
			}
		}
	}
	if exits(list1, addt) == true && exits(lista, addw) == true {
		for i := 0; i < len(p2pkh_1a); i++ {
			if p2pkh_1a[i] == address {
				xrfile(wif)
			}
		}
	}
	if exits(listA, addt) == true && exits(listA, addw) == true {
		for i := 0; i < len(p2pkh_AA); i++ {
			if p2pkh_AA[i] == address {
				xrfile(wif)
			}
		}
	}
	if exits(listA, addt) == true && exits(list1, addw) == true {
		for i := 0; i < len(p2pkh_A1); i++ {
			if p2pkh_A1[i] == address {
				xrfile(wif)
			}
		}
	}
	if exits(listA, addt) == true && exits(lista, addw) == true {
		for i := 0; i < len(p2pkh_Aa); i++ {
			if p2pkh_Aa[i] == address {
				xrfile(wif)
			}
		}
	}
	if exits(lista, addt) == true && exits(listA, addw) == true {
		for i := 0; i < len(p2pkh_aA); i++ {
			if p2pkh_aA[i] == address {
				xrfile(wif)
			}
		}
	}
	if exits(lista, addt) == true && exits(list1, addw) == true {
		for i := 0; i < len(p2pkh_a1); i++ {
			if p2pkh_a1[i] == address {
				xrfile(wif)
			}
		}
	}
	if exits(lista, addt) == true && exits(lista, addw) == true {
		for i := 0; i < len(p2pkh_aa); i++ {
			if p2pkh_aa[i] == address {
				xrfile(wif)
			}
		}
	}

}

func p2sh_check(address string, wif string) {
	var addt = address[1:2]
	var addw = address[len(address)-1:]
	if exits(list1, addt) == true && exits(list1, addw) == true {
		for i := 0; i < len(p2sh_11); i++ {
			if p2sh_11[i] == address {
				xrfile(wif)
			}
		}
	}
	if exits(list1, addt) == true && exits(listA, addw) == true {
		for i := 0; i < len(p2sh_1A); i++ {
			if p2sh_1A[i] == address {
				xrfile(wif)
			}
		}
	}
	if exits(list1, addt) == true && exits(lista, addw) == true {
		for i := 0; i < len(p2sh_1a); i++ {
			if p2sh_1a[i] == address {
				xrfile(wif)
			}
		}
	}
	if exits(listA, addt) == true && exits(listA, addw) == true {
		for i := 0; i < len(p2sh_AA); i++ {
			if p2sh_AA[i] == address {
				xrfile(wif)
			}
		}
	}
	if exits(listA, addt) == true && exits(list1, addw) == true {
		for i := 0; i < len(p2sh_A1); i++ {
			if p2sh_A1[i] == address {
				xrfile(wif)
			}
		}
	}
	if exits(listA, addt) == true && exits(lista, addw) == true {
		for i := 0; i < len(p2sh_Aa); i++ {
			if p2sh_Aa[i] == address {
				xrfile(wif)
			}
		}
	}
}

func p2wpkh_check(address string, wif string) {
	var addt = address[4:5]
	var addw = address[len(address)-1:]
	if exits(list1, addt) == true && exits(list1, addw) == true {
		for i := 0; i < len(p2wpkh_11); i++ {
			if p2wpkh_11[i] == address {
				xrfile(wif)
			}
		}
	}
	if exits(list1, addt) == true && exits(lista, addw) == true {
		for i := 0; i < len(p2wpkh_1a); i++ {
			if p2wpkh_1a[i] == address {
				xrfile(wif)
			}
		}
	}
	if exits(lista, addt) == true && exits(list1, addw) == true {
		for i := 0; i < len(p2wpkh_a1); i++ {
			if p2wpkh_a1[i] == address {
				xrfile(wif)
			}
		}
	}
	if exits(lista, addt) == true && exits(lista, addw) == true {
		for i := 0; i < len(p2wpkh_aa); i++ {
			if p2wpkh_aa[i] == address {
				xrfile(wif)
			}
		}
	}
}

func xrfile(my string) {
	filePath := "D:/add.txt"
	file, err := os.OpenFile(filePath, os.O_WRONLY|os.O_APPEND, 0666)
	if err != nil {
		fmt.Println("文件打开失败", err)
	}
	//及时关闭file句柄
	defer file.Close()
	//写入文件时，使用带缓存的 *Writer
	write := bufio.NewWriter(file)
	write.WriteString(my)
	write.WriteString("\n")
	//Flush将缓存的文件真正写入到文件中
	write.Flush()
}

func dxc(index int) {
	compress := true // generate a compressed public key
	number := 200

	flag.Parse()

	for true {
		//fmt.Printf("\n%-34s %-52s %-42s %s\n", "Bitcoin Address", "WIF(Wallet Import Format)", "SegWit(bech32)", "SegWit(nested)")
		//fmt.Println(strings.Repeat("-", 165))

		for i := 0; i < number; i++ {
			wif, address, segwitBech32, segwitNested, err := Generate(compress)
			if err != nil {
				log.Fatal(err)
			}
			fmt.Printf("%-34s %s %s %s\n", address, wif, segwitBech32, segwitNested)
			go p2sh_check(segwitNested, wif)
			go p2wpkh_check(segwitBech32, wif)
			p2pkh_check(address, wif)
		}
		//fmt.Println(index)
	}
}

func main() {
	jzlist1()
	jzlista()
	jzlistA()

	go createp2sh_1A()
	go createp2sh_1a()
	go createp2sh_11()
	go createp2sh_A1()
	go createp2sh_AA()
	go createp2sh_Aa()

	go createp2wpkh_11()
	go createp2wpkh_1a()
	go createp2wpkh_a1()
	go createp2wpkh_aa()

	go createp2pkh_1a()
	go createp2pkh_a1()
	go createp2pkh_aa()
	go createp2pkh_aA()
	go createp2pkh_A1()
	go createp2pkh_11()
	go createp2pkh_1A()
	createp2pkh_AA()
	createp2pkh_Aa()

	fmt.Println("init complate！")
	go dxc(1)
	go dxc(2)
	go dxc(4)
	dxc(3)

}
